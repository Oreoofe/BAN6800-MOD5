# CareConnect — Module 5: Stakeholder Dashboard & Presentation

## 🚀 Quick Start (Local)
```bash
pip install -r requirements.txt
streamlit run src/app.py
```
Open http://localhost:8501

## 🌐 Deploy to Streamlit Cloud (REQUIRED for grading)
1. Push this folder to your GitHub repo
2. Go to https://streamlit.io/cloud → Sign in with GitHub
3. Click "New app" → Select your repo → Set main file path: `src/app.py`
4. Click Deploy
5. Copy the live URL (format: `https://yourname-careconnect-mod5.streamlit.app`)
6. Paste that URL into your PowerPoint submission

## 📦 Package Structure
```
careconnect_mod5/
├── src/
│   └── app.py              # Streamlit dashboard (5 pages)
├── .streamlit/
│   └── config.toml         # Theme & server settings
├── docs/
│   └── Stakeholder_Presentation.pptx  # 15-slide deck
├── requirements.txt        # Deployment dependencies
└── README.md               # This file
```

## 🎨 Dashboard Pages
1. **Executive Summary** — Metrics, problem statement, roadmap
2. **Risk Predictor & What-If** — Interactive prediction + intervention scenarios
3. **What Drives Predictions** — SHAP top drivers in business language + sample patients
4. **Fairness & Ethics** — Charter principles, fairness metrics, transparency statement, limitations
5. **Operational Metrics** — Weekly trends, goal tracker, next steps

## ⚠️ Demo Mode
If no trained model is found (`artifacts/xgboost.joblib`), the dashboard runs in **demo mode**
with synthetic predictions. This lets you develop and deploy immediately. To enable live
predictions, train the Module 4 model and copy `artifacts/xgboost.joblib` into this folder.

## 📝 Deliverables Checklist
- [ ] Streamlit app deployed and live URL working
- [ ] PowerPoint presentation (12–15 slides)
- [ ] Q&A backup deck (appendix slides)
- [ ] All code committed to GitHub
- [ ] NXU-formatted references
- [ ] AI Disclosure Form

**Author:** Gladys Izuagbe (ID: 160948) | BAN 6800, Nexford University
